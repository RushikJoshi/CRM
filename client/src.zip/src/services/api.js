import axios from "axios";
import { API_BASE_URL } from "../config/api";

const API = axios.create({
  baseURL: API_BASE_URL,
});

API.interceptors.request.use((req) => {
  const token = localStorage.getItem("token");
  if (token) {
    req.headers.Authorization = `Bearer ${token}`;
  }
  return req;
});

// Global 401 handler — clears session and redirects to login
API.interceptors.response.use(
  (res) => res,
  (err) => {
    if (err.response?.status === 401) {
      // Don't auto-logout if we're actually at the Login page OR trying to login
      const isLoginRequest = err.config?.url?.includes("/auth/login");
      const isPublicPath = window.location.pathname === "/";

      if (!isLoginRequest && !isPublicPath) {
        localStorage.clear();
        window.location.replace("/");
      }
    }
    return Promise.reject(err);
  }
);

export default API;